# Oxc's modular runtime helpers

Code copied from the published package `@babel/runtime`.

All credits to the Babel team.
