# Oxc Types

Typescript definitions for Oxc AST nodes.
