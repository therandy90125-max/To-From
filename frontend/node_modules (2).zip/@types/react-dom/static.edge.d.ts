export { prerender, resumeAndPrerender, version } from "./static";
