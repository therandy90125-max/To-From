import "./react-CzMSMHK5.js";
import { require_react_dom } from "./react-dom-Cl0x47w9.js";

export default require_react_dom();
