import { require_react } from "./react-CzMSMHK5.js";

export default require_react();
